import { d as defineEventHandler, u as useRuntimeConfig } from '../../nitro/nitro.mjs';
import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { UpdateCommand, DynamoDBDocumentClient } from '@aws-sdk/lib-dynamodb';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';

const getDynamoClient = () => {
  const region = process.env.AWS_REGION || "us-east-1";
  const client = new DynamoDBClient({ region });
  return DynamoDBDocumentClient.from(client);
};
const dashboard_get = defineEventHandler(async (event) => {
  var _a;
  const startTime = Date.now();
  const config = useRuntimeConfig();
  const region = process.env.AWS_REGION || "unknown";
  const isPrimary = region === config.primaryRegion;
  const requestId = crypto.randomUUID();
  try {
    const dynamo = getDynamoClient();
    const tableName = config.dynamodbTable;
    const updateResult = await dynamo.send(new UpdateCommand({
      TableName: tableName,
      Key: {
        PK: "GLOBAL",
        SK: "COUNTER"
      },
      UpdateExpression: "SET #count = if_not_exists(#count, :zero) + :inc",
      ExpressionAttributeNames: {
        "#count": "count"
      },
      ExpressionAttributeValues: {
        ":zero": 0,
        ":inc": 1
      },
      ReturnValues: "UPDATED_NEW"
    }));
    const counter = ((_a = updateResult.Attributes) == null ? void 0 : _a.count) || 0;
    const latency = Date.now() - startTime;
    const now = /* @__PURE__ */ new Date();
    const timeFormatter = new Intl.DateTimeFormat("en-US", {
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: true
    });
    const dateFormatter = new Intl.DateTimeFormat("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric"
    });
    const regionNames = {
      "us-east-1": "N. Virginia",
      "us-west-2": "Oregon"
    };
    return {
      time: timeFormatter.format(now),
      date: dateFormatter.format(now),
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      region,
      regionName: regionNames[region] || region,
      counter,
      latency,
      renderMode: "server-side",
      requestId,
      isPrimary
    };
  } catch (error) {
    console.error("Dashboard API error:", error);
    return {
      time: (/* @__PURE__ */ new Date()).toLocaleTimeString(),
      date: (/* @__PURE__ */ new Date()).toLocaleDateString(),
      timezone: "unknown",
      region,
      regionName: "Error",
      counter: 0,
      latency: Date.now() - startTime,
      renderMode: "server-side (with errors)",
      requestId,
      error: error instanceof Error ? error.message : "Unknown error"
    };
  }
});

export { dashboard_get as default };
//# sourceMappingURL=dashboard.get.mjs.map
