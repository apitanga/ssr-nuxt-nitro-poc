import { d as defineEventHandler, c as createError, u as useRuntimeConfig } from '../../nitro/nitro.mjs';
import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { UpdateCommand, DynamoDBDocumentClient } from '@aws-sdk/lib-dynamodb';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';

const getDynamoClient = () => {
  const region = process.env.AWS_REGION || "us-east-1";
  const client = new DynamoDBClient({ region });
  return DynamoDBDocumentClient.from(client);
};
const counter_post = defineEventHandler(async (event) => {
  var _a;
  const config = useRuntimeConfig();
  try {
    const dynamo = getDynamoClient();
    const tableName = config.dynamodbTable;
    const result = await dynamo.send(new UpdateCommand({
      TableName: tableName,
      Key: {
        PK: "GLOBAL",
        SK: "COUNTER"
      },
      UpdateExpression: "SET #count = if_not_exists(#count, :zero) + :inc",
      ExpressionAttributeNames: {
        "#count": "count"
      },
      ExpressionAttributeValues: {
        ":zero": 0,
        ":inc": 1
      },
      ReturnValues: "UPDATED_NEW"
    }));
    return {
      success: true,
      counter: ((_a = result.Attributes) == null ? void 0 : _a.count) || 0
    };
  } catch (error) {
    console.error("Counter API error:", error);
    throw createError({
      statusCode: 500,
      statusMessage: "Failed to increment counter"
    });
  }
});

export { counter_post as default };
//# sourceMappingURL=counter.post.mjs.map
